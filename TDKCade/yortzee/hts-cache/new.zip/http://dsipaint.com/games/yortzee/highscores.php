<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=240">
	<meta name="description" content="DSiPaint: Games and Apps for the Nintendo DS/DSi Browser" />
	<meta name="keywords" content="DSiPaint, DS Opera SDK, Nintendo DS, Nintendo DSi, DSi, JavaScript, video games, DSi Chatroom, homebrew, Nintendo WiFi" />
	<title>High Scores: Yortzee</title>
	<link rel="shortcut icon" href="../../favicon.ico" />
	<link rel="stylesheet" href="style.css" type="text/css" />
	<script type="text/javascript">
		window.onload = function(){
			animate_yorick();
		}

		var frame=0;
		function animate_yorick(){
			frame=(frame+1)&3;
			document.getElementById('yorick1').style.backgroundPosition=(-32*frame)+'px 0px';
			document.getElementById('yorick2').style.backgroundPosition=(-32*(frame^2))+'px 0px';
			setTimeout('animate_yorick();', 250);
		}
	</script>
</head>
<body style="background: url(../../images/backgrounds/background0.png)">

	<div id="title" class="title">High Scores - Yortzee</div>
	<div id="yorick1" class="yorick" style="left:0px; top:10px"></div>
	<div id="yorick2" class="yorick" style="left:208px; top:10px"></div>

	<table class="highscores">

			<tr>
				<td style="text-shadow:1px 0px 1px #888">1</td>
				<td>GuiedGui</td>
				<td style="text-align:right">32767</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">2</td>
				<td>Leftist-Tachyon</td>
				<td style="text-align:right">375</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">3</td>
				<td>Weeeee</td>
				<td style="text-align:right">375</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">4</td>
				<td>Walrus</td>
				<td style="text-align:right">356</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">5</td>
				<td>TacoRocco</td>
				<td style="text-align:right">355</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">6</td>
				<td>Kavanagh</td>
				<td style="text-align:right">352</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">7</td>
				<td>MancarCamoran</td>
				<td style="text-align:right">352</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">8</td>
				<td>bradleybrown1198</td>
				<td style="text-align:right">349</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">9</td>
				<td>Shanice</td>
				<td style="text-align:right">349</td>
			</tr>
			<tr>
				<td style="text-shadow:1px 0px 1px #888">10</td>
				<td>Jamerson</td>
				<td style="text-align:right">348</td>
			</tr>	</table>

	<form onsubmit="return false;">
		<input type="button" class="button" style="left:2px; top:156px" value="Exit" onclick="location.href='../../menu_games.php';" />
		<input type="button" class="button" style="left:198px; top:156px" value="Play" onclick="location.href='index.php';" />
	<form>

	<script type="text/javascript">
		var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		try{ _gat._getTracker('UA-702344-9')._trackPageview(); }catch(err){}
	</script>
</body>
</html>
