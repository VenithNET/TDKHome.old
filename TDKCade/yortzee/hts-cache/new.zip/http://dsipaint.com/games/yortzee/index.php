<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=240">
	<meta name="description" content="DSiPaint: Games and Apps for the Nintendo DS/DSi Browser" />
	<meta name="keywords" content="DSiPaint, DS Opera SDK, Nintendo DS, Nintendo DSi, DSi, JavaScript, video games, DSi Chatroom, homebrew, Nintendo WiFi" />
	<title>Yortzee, starring Yorick</title>
	<link rel="shortcut icon" href="../../favicon.ico" />
	<link rel="stylesheet" href="style.css" type="text/css" />
	<script type="text/javascript">
		var userid = 0;
	</script>
	<script type="text/javascript" src="scripts/yortzee.js"></script>
	<script type="text/javascript">
		var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		try{ _gat._getTracker('UA-702344-9')._trackPageview(); }catch(err){}
	</script>
</head>
<body style="background: url(../../images/backgrounds/background0.png)">
	<div id="title" class="title">Yortzee</div>
	<div id="yorick" class="yorick"></div>

	<form onsubmit="return false;">
		<input type="button" id="die0" style="left:4px" onclick="lock_die(0);" />
		<input type="button" id="die1" style="left:52px" onclick="lock_die(1);" />
		<input type="button" id="die2" style="left:100px" onclick="lock_die(2);" />
		<input type="button" id="die3" style="left:148px" onclick="lock_die(3);" />
		<input type="button" id="die4" style="left:196px" onclick="lock_die(4);" />
		<input type="button" id="exit_button" class="button" style="left:25px; top:155px" value="Quit" onclick="location.href='highscores.php';" />
		<input type="button" id="roll_button" class="button" style="left:123px; top:155px" value="Roll" onclick="animate_yorick(0);" />
	<form>

	<table style="background:#eee; border-collapse:collapse; left:10px; position:absolute; top:65px; border:1px solid #000">
		<tr>
			<th>Ones</th><td id="score_0" onclick="claim(0);">&nbsp;</td><th>Three of a Kind</th><td id="score_7" onclick="claim(7);">&nbsp;</td>
		</tr>
		<tr>
			<th>Twos</th><td id="score_1" onclick="claim(1);">&nbsp;</td><th>Four of a Kind</th><td id="score_8" onclick="claim(8);">&nbsp;</td>
		</tr>
		<tr>
			<th>Threes</th><td id="score_2" onclick="claim(2);">&nbsp;</td><th>Full House</th><td id="score_9" onclick="claim(9);">&nbsp;</td>
		</tr>
		<tr>
			<th>Fours</th><td id="score_3" onclick="claim(3);">&nbsp;</td><th>Small Straight</th><td id="score_10" onclick="claim(10);">&nbsp;</td>
		</tr>
		<tr>
			<th>Fives</th><td id="score_4" onclick="claim(4);">&nbsp;</td><th>Large Straight</th><td id="score_11" onclick="claim(11);">&nbsp;</td>
		</tr>
		<tr>
			<th>Sixes</th><td id="score_5" onclick="claim(5);">&nbsp;</td><th>YORTZEE</th><td id="score_12" onclick="claim(12);">&nbsp;</td>
		</tr>
		<tr>
			<th>Bonus</th><td id="score_6" style="background:#888">&nbsp;</td><th>Chance</th><td id="score_13" onclick="claim(13);">&nbsp;</td>
		</tr>

	</table>

	<div style="font-size:16px; height:30px; left:190px; text-align:right; top:70px; width:40px" id="total_score">0</div>
</body>
</html>
